export const expressController = (req, res) => {
    res.send(
      "Az Express egy minimalista webes keretrendszer, amely a Node.js-hez készült."
    );
  };
  