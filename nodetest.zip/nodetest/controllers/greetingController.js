export const greetingController = (req, res) => {
    res.send("Hello, Ördög Balázs");
  };
  