export const nodejsController = (req, res) => {
    res.send(
      "A Node.js egy olyan szerveroldali JavaScript futtatókörnyezet, amely a V8 JavaScript motorra épül."
    );
  };